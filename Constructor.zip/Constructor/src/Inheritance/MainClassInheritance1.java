package Inheritance;

class Parent5{
	private int i;  //scope with in a class nobody can access data
	public int j;
	int k; //default
	private void method1() {
		System.out.println("Private method display private data "+i);
	}
	void displayData() {
		System.out.println("DisplayData method of parent class");
		method1();
		}
}
class Child5 extends Parent5{ //for inheritance use the keyword extends
	void display() {
		//System.out.println("i="+pob.i); //private
		System.out.println("j="+j);
		System.out.println("k="+k);
}
	//overriding is a run time polymorphisam
	public void displayData() {         //function overriding , hides the parent function in child class
		System.out.println("DisplayData function of child class");
		super.displayData();      //super is used to call parent class overridden methods
                                  //from child class
		}
}
public class MainClassInheritance1 {
	public static void main(String[] args) {
		Child5 cob=new Child5();
		cob.display();
		cob.displayData(); //which function is going to execute
                           //Parent pob=new Parent();
		}
}


