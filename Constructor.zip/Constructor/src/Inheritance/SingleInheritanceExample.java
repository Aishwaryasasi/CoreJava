package Inheritance;
class Parent1
{
	private int i;
	public int j;
	int k;
	void displayParent()
	{
		System.out.println("Display method in Parent class "+i);
	}
}
class Child1 extends Parent1
{
	void display()
	{
		System.out.println("j = "+j);
		System.out.println("k = "+k);
	}
}

public class SingleInheritanceExample {

	public static void main(String[] args) {
		Child1 cob1=new Child1();
		cob1.displayParent();
		cob1.display();
		
		

	}

}
