//Program for constructors using inheritance
package Inheritance;
class Parent3
{
	Parent3()
	{
		System.out.println("Parent Constructor");
	}
}
class Child3 extends Parent3
{
	Child3()
	{
		System.out.println("Child class constructor");
	}
}

public class ParentChildConstructor {

	public static void main(String[] args) {
		Child3 cod=new Child3();
		
	}

}
