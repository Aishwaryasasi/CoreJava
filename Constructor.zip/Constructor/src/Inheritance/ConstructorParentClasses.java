//Constructor calling
package Inheritance;
class Parents1{
Parents1(){
System.out.println("Parent Constructor");
}
}
class Childs1 extends Parents1{
Childs1(){
System.out.println("Child class constructor");
}
}
public class ConstructorParentClasses{

public static void main(String[] args) {

Childs1 c1=new Childs1();//create an object of child class
                      //parent class constructor will execute first

}

}