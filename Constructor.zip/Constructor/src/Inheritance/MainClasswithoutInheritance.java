//Program without inheritance accessing the other class
package Inheritance;
class Parent
{
	public int j;
	int k;
}
class Child
{
	void display()
	{
		Parent pob=new Parent();   ///HAS-A Relation
		System.out.println("j = "+pob.j);
		System.out.println("k = "+pob.k);
	}
}

public class MainClasswithoutInheritance {

	public static void main(String[] args) {
		Child cob=new Child();
		cob.display();

	}

}
