package Inheritance;
class ParentData{
private int i;  //scope with in a class nobody can access data
public int j;
int k; //default
private void method1() 
{
	System.out.println("Private method display private data "+i);
	}
public void displayParent() 
{
	System.out.println("Display method of parent class");
	method1();
	}
}

class ChildData extends ParentData  //for inheritance use the keyword extends
{ 
	void display() 
	{
	    //System.out.println("i="+pob.i); //private
		System.out.println("j="+j);
        System.out.println("k="+k);
        }
	}

public class MainClassInheritance 
{
public static void main(String[] args) {
	ChildData cob=new ChildData();
	cob.display();
	cob.displayParent();
	}
}

