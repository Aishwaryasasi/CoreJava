//Constructor calling
package Inheritance;
class Parents{
Parents(){
System.out.println("Parent1 Constructor");
}
}
class Parent2 extends Parents{
Parent2(){
System.out.println("Parent2 Constructor");
}
}
class Childs extends Parent2{
Childs(){
System.out.println("Child class constructor");
}
}
public class ConstructorParentChildMain {

public static void main(String[] args) {

Childs c1=new Childs();//create an object of child class
                      //parent class constructor will execute first

}

}

