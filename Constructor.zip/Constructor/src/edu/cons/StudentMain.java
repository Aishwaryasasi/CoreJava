//Program for default and parameter constructor 
package edu.cons;
import java.util.Scanner;
class Student2
{
	private int sid;
	private String sname;
	public Student2()
	{
		
	}
	Student2(int sid,String sname)
	{
		this.sid=sid;
		this.sname=sname;
	}
	void display()
	{
		System.out.println("Student name "+sname);
		System.out.println("Student id : "+sid);
	}
	void inputData()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name :");
		sname=sc.nextLine();
		System.out.println("Enter the ID :");
		sid=sc.nextInt();
		sc.close();
	} 
	
}
public class StudentMain {

	public static void main(String[] args) {
		Student2 s1= new Student2(1,"Aishwarya");
		Student2 s2= new Student2(2,"Akshara");
		s1.display();
		s2.display();
		Student2 s3=new Student2();
		s3.inputData();
		s3.display();
	}

}
