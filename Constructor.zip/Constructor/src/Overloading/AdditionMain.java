//Program for function overloading
package Overloading;
class Addition
{
	public void add(int i,int j)
	{
		int s=i+j;
		System.out.println("Sum of integer value is : "+s);
	}
	public void add(float i,float j)
	{
		float s=i+j;
		System.out.println("Sum of float value is : "+s);
	}
	public void add(double i,double j)
	{
		double s=i+j;
		System.out.println("Sum of double value is : "+s);
	}
}
public class AdditionMain {

	public static void main(String[] args) {
		Addition aob1=new Addition();
		aob1.add(3,6);
		aob1.add(3.5f,6.7f);
		aob1.add(3.8,2.8);
		

	}

}
