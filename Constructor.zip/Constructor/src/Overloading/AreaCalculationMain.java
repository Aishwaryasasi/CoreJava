//program to find area of shapes using function Overloading
package Overloading;
class AreaCalculation
{
	public void area(int side)
	{
		int sqr=side*side;
		System.out.println("Area of a square :"+sqr+" sqrunits");
	}
	public void area(int l,int b)
	{
		int rec=l*b;
		System.out.println("Area of a rectangle :"+rec+" sqrunits ");
	}
	public void area(float r)
	{
		float cir=3.14159f*r*r;
		System.out.println("Area of a circle :"+cir+" sqrunits ");
	}
	public void area(float b,float h)
	{
		float tri=0.5f*b*h;
		System.out.println("Area of a triangle :"+tri+" sqrunits ");
	}
}

public class AreaCalculationMain {

	public static void main(String[] args) {
		AreaCalculation aob=new AreaCalculation();
		aob.area(6);
		aob.area(5,6);
		aob.area(4.5f);
		aob.area(2.3f,3.3f);
	}
}
