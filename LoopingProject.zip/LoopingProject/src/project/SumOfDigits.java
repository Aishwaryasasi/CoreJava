//Program to find sum of Digits
package project;
import java.util.Scanner;

public class SumOfDigits {

	public static void main(String[] args) {
		int num,digit,sum;
		sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number :");
		num=sc.nextInt();
		while(num>0)
		{
			digit=num%10; //eg:num=234 234%10=4 23%10=3 2%10=2
			sum=sum+digit; //0+4=4   4+3=7 7+2=9
			num=num/10;   //234/10=23  23/10=2 2/10=condition fails come out of the loop
		}
		System.out.println("Sum of digits : "+sum);
		sc.close();
		}

}
