//Program to find Number of digits
package project;
import java.util.Scanner;

public class CountOfDigits {

	public static void main(String[] args) {
		int num,count;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number: ");
		num=sc.nextInt();
		count=0;
		while(num>0)
		{
			num=num/10;
			count++;
		}
		System.out.print("Number of digits = "+count);
		sc.close();
	}

}
