package project;
import java.util.Scanner;
public class FibonacciSeries {

	public static void main(String[] args) {
		int num,fnum,snum,nextnum;
		fnum=1;
		snum=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of terms: ");
		num=sc.nextInt();
		System.out.println("Fibonacci series ");
		System.out.print(fnum+" ");
		System.out.print(snum+ " ");
		for(int i=1;i<=num-2;i++) {
			nextnum=fnum+snum;
			System.out.print(nextnum+"  ");
			fnum=snum;
			snum=nextnum;
		}
		sc.close();
    }

}
