package project;

public class IncrementDecrement {

	public static void main(String[] args) {
		int a,k;
		a=1;
		k=++a + a++;
		System.out.println("a = "+a);
		System.out.println("k = "+k);

	}

}
