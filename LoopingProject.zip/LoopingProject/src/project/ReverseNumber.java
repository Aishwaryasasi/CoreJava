//Program to reverse the number
package project;
import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		int num,digit;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the numbers :");
		num=sc.nextInt();
		while(num>0)
		{
			digit=num%10; // or rev=rev*10+digit initially rev=0
			System.out.print(digit);
			num=num/10; //234/10=23  23/10=2 
		}
		sc.close();
	}

}
