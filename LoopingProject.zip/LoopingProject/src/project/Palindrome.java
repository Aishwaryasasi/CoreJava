//Program to find the given number is Palindrome or not
package project;
import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		int num,revnum,digit,originalnum;
		revnum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number : ");
		num=sc.nextInt();
		originalnum=num;
		while(num>0)
		{
			digit=num%10;
			revnum=revnum*10+digit;
			num=num/10;
		}
		if(originalnum==revnum)
		{
			System.out.println(originalnum+ " is a palindrome number");
		}
		else
		{
			System.out.println(originalnum+" is not a palindrome number");
		}
		sc.close();
		}
}