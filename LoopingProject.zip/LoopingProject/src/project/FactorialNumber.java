package project;
import java.util.Scanner;
public class FactorialNumber {

	public static void main(String[] args) {
		int num;
		long fact=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number :");
		num=sc.nextInt();
		int k=num;
		for(int i=1;i<=num;++i)
		{
			fact=fact*i;
		}
		System.out.println("The factorial of "+k+" is "+fact );
		sc.close();
	}

}
