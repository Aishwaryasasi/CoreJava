//Program to find natural ,odd and even numbers all in one program
package project;

public class SumNaturalEvenOdd {

	public static void main(String[] args) {
		int i,nsum,oddsum,evensum;
		nsum=0;
		oddsum=0;
		evensum=0;
		i=1;
		while(i<=100)
		{
			nsum=nsum+i;  //natural numbers from 1 to 100
			if(i%2==0)
			{
				evensum=evensum+i;  //even number
			}
			if(i%2!=0)
			{
				oddsum=oddsum+i;     //odd number
			}
			i=i+1;
		}
		System.out.println("Natural sum from 1 to 100: "+nsum);
		System.out.println("Even sum from 2 to 100: "+evensum);
		System.out.println("Odd sum from 1 to 100 : "+oddsum);
		

	}

}
