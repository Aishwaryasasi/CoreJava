//Program to find 1 to n natural number from user input
package project;
import java.util.Scanner;
public class SumUsingUserInput {

	public static void main(String[] args) {
		int i,j,sum;
		sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of i and j: ");
		i=sc.nextInt();
		j=sc.nextInt();
		while(i<=j)
		{
			sum = sum+i;
			i++;
		}
		System.out.println("The sum of 1 to 100 natural numbers is: "+sum);
		sc.close();

	}

}
