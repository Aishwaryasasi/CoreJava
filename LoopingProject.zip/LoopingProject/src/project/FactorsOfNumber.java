//Program to find factors of a Number
package project;
import java.util.Scanner;

public class FactorsOfNumber {

	public static void main(String[] args) {
		int num,i;
		i=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number :");
		num=sc.nextInt();
		while(i<=num) 
		{
			if(num%i==0)
			{
				System.out.print(i+ " ");
			}
			i++;
		}
			
		sc.close();
	}

}
