package project;

import java.util.Scanner;

public class SumOfEvenNumbers {

	public static void main(String[] args) {
		int i,j,sum,k;
		sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of i and j: ");
		i=sc.nextInt();
		j=sc.nextInt();
		k=i;
		while(i<=j)
		{
			sum = sum+i;
			i=i+2;
		}
		System.out.println("The sum of "+k+ " and "+j+ " is :" +sum);
		sc.close();
	}

}
