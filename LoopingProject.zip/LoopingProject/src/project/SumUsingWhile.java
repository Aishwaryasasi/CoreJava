//Program to
package project;

public class SumUsingWhile {

	public static void main(String[] args) {
		int i,sum;
		i=1;
		sum=0;
		while(i<=100)
		{
			sum=sum+i;
			i++;
		}
		System.out.println("The sum is "+sum);

	}

}
