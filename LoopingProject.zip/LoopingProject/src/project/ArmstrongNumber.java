//Program to find the given number is Armstrong or not
package project;
import java.util.Scanner;

public class ArmstrongNumber {
	public static void main(String[] args) {
		int num,sum,digit,k;
		sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number :");
		num=sc.nextInt();
		k=num;
		while(num>0)
			{
			digit=num%10;  
			sum=sum+(digit*digit*digit);
			num=num/10;
			}
		if(sum==k) {
			System.out.print(k+ " is an Armstrong number");
		}
		else {
			System.out.println(k+" is not an Armstrong Number");
		}
		sc.close();
	}

}
