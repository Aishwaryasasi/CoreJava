package com.pack2;

public class Pack2MainClass {
	int defi;
	private int privateval;
	public int pubval;
	protected int protval;
	

}
