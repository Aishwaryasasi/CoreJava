package com.pack1;

import com.pack2.Pack2MainClass;

class Pack1Class
{
	int i;
	private int j;
	public int k;
	protected int p;
	public void Demo()
	{
		System.out.println(j);
	}
}
class MyClass extends Pack2MainClass
{
	public void display() 
	{
		System.out.println(protval);
		System.out.println(pubval);
	}
}
public class PackMainExample {

	public static void main(String[] args) 
	{
		Pack1Class p1=new Pack1Class();
		System.out.println("Defaul value "+p1.i);
		System.out.println("Public data "+p1.k);
		System.out.println("Protected data "+p1.p);
		//Pack2
		Pack2MainClass p2=new Pack2MainClass();
		System.out.println("Public class ="+p2.pubval);
	}
}


