package array.com;
import java.util.Scanner;
public class ArrayDemo {

	public static void main(String[] args) {
		int arr[]=new int[5];//declare array
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 5 nums :");
		for(int i=0;i<5;i++)
		{
			arr[i]=sc.nextInt();  //storing elements into an array
		}
		System.out.println("Entered elements are :"); //display array elements
		for(int i=0;i<5;i++)
		{
			System.out.print(arr[i]+" ");
		}
        sc.close();
	}

}
