package com.compiletimeexcep;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Employee
{
	private String empname;
	private int eid;
	private double empsalary;
	public void inputData()
	{
		BufferedReader bufferedreader1=new BufferedReader(new InputStreamReader(System.in));
		try {
			System.out.println("Enter Employee name :");
			empname=bufferedreader1.readLine();
			System.out.println("Enter employee Id :");
			eid=Integer.parseInt(bufferedreader1.readLine());
			System.out.println("Enter the salary : ");
			empsalary=Double.parseDouble(bufferedreader1.readLine());
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	public void display()
	{
		System.out.println("Employee name : "+empname);
		System.out.println("Employee Id : "+eid);
		System.out.println("Employee salary : "+empsalary);
	}
}

public class CheckedReadingData {

	public static void main(String[] args) {
		Employee employee=new Employee();
		employee.inputData();
		employee.display();
		}

}
