//Program for checked exception using throws keyword
package com.compiletimeexcep;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Product
{
	private String pname;
	private int pid;
	
	public void inputData() throws IOException
	{
		BufferedReader bufferedreader=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the product Name :");
		pname=bufferedreader.readLine();
		System.out.println("Enter product Id :");
		pid=Integer.parseInt(bufferedreader.readLine());
	}
	public void display()
	{
		System.out.println("Product id : "+pid);
		System.out.println("Product Name : "+pname);
	}
}

public class ReadDataExample {

	public static void main(String[] args) throws IOException {
		Product pid=new Product();
		pid.inputData();
		pid.display();

	}

}
