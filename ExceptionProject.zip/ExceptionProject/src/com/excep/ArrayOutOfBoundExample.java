package com.excep;

public class ArrayOutOfBoundExample {

	public static void main(String[] args) {
		int ar[]=new int[3];
		try
		{
			ar[3]=60;
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			e.printStackTrace();
		}
		finally
		{
			System.out.println("Final block");
		}
		

	}

}
