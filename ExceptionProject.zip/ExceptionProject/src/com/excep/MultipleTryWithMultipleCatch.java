//Program for multiple try with multiple catch
package com.excep;

public class MultipleTryWithMultipleCatch {

	public static void main(String[] args) {
		int a=10,b=0,c=0;
		String s=null;
		int ar[]=new int[4];
		System.out.println("Before Eecution");
		try {
			c=a/b;
		}
		catch(ArithmeticException e)
		{
			e.printStackTrace();
		}
		System.out.println("Arithmetic output = "+c);
		int len=0;
		try
		{
			len=s.length();
		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		}
		System.out.println("Length of the string = "+len);
		try
		{
			ar[5]=50;
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			e.printStackTrace();
		}
		System.out.println("Array of value");

	}

}
