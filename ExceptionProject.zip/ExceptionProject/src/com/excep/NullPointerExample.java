package com.excep;

public class NullPointerExample {

	private static String str;

	public static void main(String[] args) {
		str = null;
		int len=0;
		try 
		{
			len=str.length();
		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		}
		System.out.println("Length of the String "+len);

	}

}
