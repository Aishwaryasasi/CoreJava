//Program for single try with Multiple catch
package com.excep;

public class TryWithMultipleCatch {

	public static void main(String[] args) {
		int a=10,b=0,c;
		int ar[]=new int[5];
		System.out.println("Starting program");
		try
		{
			c=a/b;     // first exception will occur
			ar[6]=40;  //this will not be handled
		}
		catch(ArithmeticException e)
		{
			e.printStackTrace();
		}
		catch(ArrayIndexOutOfBoundsException l)
		{
			l.printStackTrace();
		}
		catch(Exception e)  //superclass shoul be handled at last
		{
			e.printStackTrace();
		}
		finally
		{
			System.out.println("Finally block executes here");
		}
		System.out.println("End of the Program");
		

	}

}
