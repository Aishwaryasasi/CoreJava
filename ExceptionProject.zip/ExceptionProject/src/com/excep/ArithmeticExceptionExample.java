package com.excep;

import java.util.Scanner;

public class ArithmeticExceptionExample {

	public static void main(String[] args) {
		int n1,n2,n3=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 2 numbers :");
		n1=sc.nextInt();
		n2=sc.nextInt();
		try {
			n3=n1/n2;
		}
		catch(ArithmeticException e)
		{
			e.printStackTrace();
		}
		System.out.println("The output = "+n3);
		sc.close();
	}

}
