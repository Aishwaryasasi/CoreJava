package com.excep;

public class ExceptionExample {

	public static void main(String[] args) {
		int a=20,b=0,c=0;
		System.out.println("Before division");
		try {
			c=a/b;
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		System.out.println("After Division "+c);

	}

}
