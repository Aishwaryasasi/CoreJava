package com.excep;

public class FinallyExample {

	public static void main(String[] args) {
		int a=20,b=0,c=0;
		System.out.println("Before division");
		try {
			c=a/b;
		}
		catch(ArithmeticException e)
		{
			System.out.println("Catch will execute only when there is a error");
			System.out.println(e);
		}
		finally
		{
			System.out.println("Finally will execute always");
			System.out.println("Final block");
		}
		System.out.println("After Division "+c);
		
	}
}