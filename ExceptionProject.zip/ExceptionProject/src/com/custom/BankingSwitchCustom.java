//Program for Banking application using custom Exception
package com.custom;
import java.util.Scanner;
class Banking
{
	private float amount;
	public Banking(float amount)
	{
		this.amount=amount;
	}
	public void depositAmount(float deposit_amount)
	{
		System.out.println("Your Balance amount : "+amount);
		amount=amount+deposit_amount;
		System.out.println("Amount is deposited to your account "+amount);
	}
	public void withdrawalAmount(float withdraw_amount)
	{
		System.out.println("Your Balance amount before Withdrawal : "+amount);
		if(withdraw_amount>amount)
		{
			try
			{
				throw new BankingException("Insufficient Balance");
			}
			catch(BankingException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			amount=amount-withdraw_amount;
			System.out.println("After withdraw your balance is : "+amount);
		}
	}
}
public class BankingSwitchCustom {

	public static void main(String[] args) {
		Banking bank=new Banking(20000);
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			int ch;
			float damount,wamount;
			System.out.println("Banking Choice ");
			System.out.println("1. Deposit");
			System.out.println("2. Withdrawal");
			System.out.println("Enter your choice");
			ch=sc.nextInt();
			switch(ch){
			case 1:
				System.out.println("Enter the amount to deposit");
				damount=sc.nextFloat();
				bank.depositAmount(damount);
				break;
			case 2:
				System.out.println("Enter the amount to withdraw");
				wamount=sc.nextFloat();
				bank.withdrawalAmount(wamount);
				break;
			}
		System.out.println("Do you want to continue, Yes/No");
		String option=sc.next();
		if(option.equalsIgnoreCase("No"))
		{
			System.exit(0);
		}
	}	
  }
}
