package com.custom;

import java.util.Scanner;
class BankwithdrawException extends Exception
{
	public BankwithdrawException(String str)
	{
		super(str);
	}
}
class Bank
{
	private double total_amount=20000;
	private double withdraw_amount;
	private double balance_amount;
	int choice;
	

	public void inputData()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the amount to withdraw :");
		withdraw_amount=sc.nextDouble();
		sc.close();
	}
	
	public void Withdrawal()
	{
		if(total_amount<withdraw_amount)
		{
			try
			{
				throw new BankwithdrawException("The withdrawal amount is higher than the total amount in account");
			}
			catch(BankwithdrawException bankobj)
			{
				bankobj.printStackTrace();
				
			}
		}
		else {
			balance_amount=total_amount-withdraw_amount;
			System.out.println("The balance amount after withdrawal = "+balance_amount);
			System.out.println("Successfully withdrawn the amount");
		}
	}	
}

public class BankWithdrawAmount {

	public static void main(String[] args) {
		Bank bank=new Bank();
		bank.inputData();
		bank.Withdrawal();
		}

}
