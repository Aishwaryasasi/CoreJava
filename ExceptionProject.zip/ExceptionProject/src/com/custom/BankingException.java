package com.custom;

public class BankingException extends Exception {

	public BankingException(String s)
	{
		super(s);
	}
	
}
