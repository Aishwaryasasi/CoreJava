package com.custom;

import java.util.Scanner;
class AgeCheckException extends Exception
{
	public AgeCheckException(String s)
	{
		super(s);
	}
	
}
class AgeCheckVote
{
	private int person_age;
	public void inputData()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the person Age :");
		person_age=sc.nextInt();
	}
	public void display()
	{
		if(person_age<18)
		{
			try
			{
				throw new  AgeCheckException("Age is less than 18 not eligible for voting");
				
			}
			catch(AgeCheckException ageobj)
			{
				ageobj.printStackTrace();
			}
		}
		else
		{
			System.out.println("Eligible for voting");
		}
	}
}

public class CustomExceptionExample {

	public static void main(String[] args) {
		AgeCheckVote agecheckvote=new AgeCheckVote();
		agecheckvote.inputData();
		agecheckvote.display();
		}
}
