package com.abs;
abstract class Person
{
	public abstract void display();
	void salaryDisplay()
	{
		System.out.println("SalaryDisplay");
	}
}
class Employee extends Person
{
	public void display()
	{
		System.out.println("Display Method of abstarct class");
	}
}

public class AbstractExample {

	public static void main(String[] args) {
		Employee eob=new Employee();
		eob.display();
		eob.salaryDisplay();
		

	}

}
