package com.abs;
interface MyInterfaces
{
	int i=100;
	void method1();
	void method2();
}
class MyClass1 implements MyInterface
{
	@Override
	public void method1() {
		System.out.println("Method1 displayed");
		
	}
	@Override
	public void method2() {
		System.out.println("Method2 displayed");
		}
}

public class AbstractInterface {

	public static void main(String[] args) {
		MyClass1 cob=new MyClass1();
		cob.method1();
		cob.method2();
		}
}


