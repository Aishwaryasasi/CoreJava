package com.abs;
interface MyInterface
{
	int i=100;
	void method1();
	void method2();
}
abstract class MyClass implements MyInterface
{
	@Override
	public void method1() {
		System.out.println("Method1 displayed");
		
	}
}
class Example extends MyClass
{
	public void method2()
	{
		System.out.println("Method2 displayed here");
	}
}

public class InterfaceExample {

	public static void main(String[] args) {
		Example eob=new Example();
		eob.method1();
		eob.method2();
		
		}
}
