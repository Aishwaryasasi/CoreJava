//Program using abstract keyword
package com.abs;
abstract class Bank
{
	abstract public void rateOfInterest();
}
	
class Sbi extends Bank
{
	public void rateOfInterest()
	{
		System.out.println("Rate of Interest of SBI "+4.6f);
		
	}
}
class Hdfc extends Bank
{

	@Override
	public void rateOfInterest() {
		System.out.println("Rate of Interest of HDFC Bank "+7.5f);
	}
}
class Indian extends Bank
{

	@Override
	public void rateOfInterest() {
		System.out.println("Rate of Interest of Indian Bank "+5.5f);
	}
}

public class BankExampleAbstract {

	public static void main(String[] args) {
		Sbi sb=new Sbi();
		sb.rateOfInterest();
		Hdfc hob=new Hdfc();
		hob.rateOfInterest();
		Indian iob=new Indian();
		iob.rateOfInterest();
		
		//another way
		
		Bank obj;
		obj=new Sbi();
		obj.rateOfInterest();
		obj=new Hdfc();
		obj.rateOfInterest();
		obj=new Indian();
		obj.rateOfInterest();
	}
}
