//Program to find areas of shape using Abstract class
package com.abs;
abstract class Shape
{
	float area;
	abstract public void calculateArea();
	void display()
	{
		System.out.println("Area of shapes :");
	}
}
class Square extends Shape
{
	float side;
	Square(float side)
	{
		super();
        this.side=side;
	}
	public void calculateArea()
	{
		area=side*side;
		System.out.println("Area of square = "+area);
	}
}
class Rectangle extends Shape
{
	float length,breadth;
	Rectangle(float length,float breadth)
	{
		this.length=length;
		this.breadth=breadth;
	}
	public void calculateArea()
	{
		area=length*breadth;
		System.out.println("Area of Rectagle = "+area);
	}
}
public class ShapeAbstract {

	public static void main(String[] args) {
		Square sob=new Square(2.4f);
		sob.display();
		sob.calculateArea();
		Rectangle rob=new Rectangle(2.2f,3.2f);
		rob.calculateArea();
		//Another way
		Shape sob1;
		sob1=new Square(2.4f);
		sob1.calculateArea();
		sob1=new Rectangle(2.2f,3.2f);
		sob1.calculateArea();
		
				

	}

}
