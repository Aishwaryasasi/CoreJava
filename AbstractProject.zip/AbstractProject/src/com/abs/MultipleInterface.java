//Multiple inheritance through interface
package com.abs;
interface A
{
	void method1();
}
interface B
{
	void method2();
}
interface C extends A,B
{
	void method3();
}
class MainMethod implements C
{

	@Override
	public void method1() {
		System.out.println("Method1 displayed");
	}
	@Override
	public void method2() {
		System.out.println("Method2 Displayed");
		}
	@Override
	public void method3() {
		System.out.println("Method3 Displayed");
	}
}

public class MultipleInterface {

	public static void main(String[] args) {
		MainMethod mob=new MainMethod();
		mob.method1();
		mob.method2();
		mob.method3();
		
		

	}

}
