package com.str;

public class ReplaceString {

	public static void main(String[] args) {
		String st="edubridge india pvt ltd";
		String rev=st.replace('a', 'e');
		System.out.println("After replacing : "+rev);
		String revword=st.replace("india", "USA");
		System.out.println("Replace word : "+revword);
		
		StringBuffer sb=new StringBuffer(st);  //Thread Safe(Thread based)
		sb.reverse();
		System.out.println(sb);
		StringBuilder sb1=new StringBuilder(st);// not thread safe
		System.out.println(sb1.reverse());
	}

}
