package com.str;

public class SubString {

	public static void main(String[] args) {
		String str="Sub string";
		String str1="Edubridge India";
		System.out.println(str.substring(2)); // index always starts from zero
		System.out.println(str1.substring(4, 10));  // beginning index, ending index-1)

	}

}
