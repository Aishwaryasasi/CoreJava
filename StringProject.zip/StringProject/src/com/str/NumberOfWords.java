//Program to find number of words in a String
package com.str;

import java.util.Scanner;

class User{
	private int count=0;
	private String st;
	void input()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the sentence");
		st=sc.nextLine();
		sc.close();
	}
	
	void findWords()
	{
		for(int i=0;i<st.length();i++)
		{
			char ch=st.charAt(i);
			if(ch==' ')
			{
				count++;
			}
		}
		System.out.println(count+1);
	}
	
}

public class NumberOfWords {

	public static void main(String[] args) {
		User uob=new User();
		uob.input();
		uob.findWords();
		}
}
