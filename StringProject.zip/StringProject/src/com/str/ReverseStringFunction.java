package com.str;

public class ReverseStringFunction {

	public static void main(String[] args)  {
		String str ="Edubridge India ";
		StringBuffer sb=new StringBuffer();
		sb.append(str);
		sb.reverse();
		System.out.println(sb);
		/*String rev="";
		//char ch[]=new char[10];
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i);
			rev=rev+ch;
		
		}
		System.out.println(rev);
		/*
			ch=str.charAt(i);
			if(ch==' ')
			{
				System.out.print(str.charAt(i+1)+".");
				
				for(int i=str.length-1;i>=0;i--)
				{
					rev=rev+ch[j];
				}
				System.out.print(rev+" ");
				System.out.println();*/
		
			
	
		
	}
		
}


