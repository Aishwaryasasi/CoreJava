package com.str;

import java.util.Scanner;

public class SubString1 {
	public static void main(String[] args) {
		String st;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the sentence");
		st=sc.nextLine();
		//System.out.println(st.charAt(0)+"."+st.charAt(9)+"."+st.substring(20)); 
		System.out.print(st.charAt(0)+".");
		for(int i=0;i<st.length();i++)
		{
			char ch=st.charAt(i);
			if(ch==' ')
			{
				System.out.print(st.charAt(i+1)+".");
				break;
			}
		}
		int  li=st.lastIndexOf(' ');
		System.out.print(st.substring(li));
		sc.close();
	}

}
