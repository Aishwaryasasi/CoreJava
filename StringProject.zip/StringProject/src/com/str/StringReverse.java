package com.str;

public class StringReverse {

	public static void main(String[] args)
	{
		String str="Edubridge Learning center";
		StringBuffer sb=new StringBuffer(str);
		StringBuffer st1 = sb.reverse();
		System.out.println(st1);
		for(int i=0;i<st1.length();i++)
		{
			char ch=st1.charAt(i);
			if(ch ==' ')
			{
				for(int j=st1.length()-1;j>0;j--)
				{
					System.out.print(st1.charAt(j));
				}
			}
		}
			
		//System.out.println(st1);
		
			
		}
}