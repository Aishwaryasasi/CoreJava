package com.str;

public class CheckVowels {

	public static void main(String[] args) {
		int count=0;
		String s="edubridge";
		System.out.println("Number of characters in a string = "+s.length());
		for(int i=0;i<s.length();i++)
		{
			char ch=s.charAt(i);
			if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u')
			{
				count++;
			}
		}
		System.out.println("No of vowels in a string = "+count);
		for(int j=s.length()-1;j>=0;j--)
		{
			System.out.print(s.charAt(j));
		}

	}

}
