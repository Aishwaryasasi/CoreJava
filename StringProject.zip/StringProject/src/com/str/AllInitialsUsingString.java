//Program to print All Initial Values in a string
package com.str;

import java.util.Scanner;

public class AllInitialsUsingString {

	public static void main(String[] args) {
		String str;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the sentence");
		str=sc.nextLine();
		System.out.print(str.charAt(0)+".");
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i);
			if(ch==' ')
			{
				System.out.print(str.charAt(i+1)+".");
			}
		}
		sc.close();
	}
}


