//Program to insert a string using Insert() function
package com.str;

public class InsertFunction {

	public static void main(String[] args) {
		String str="Edubridge India pvt ltd";
		StringBuffer sb1=new StringBuffer(str);
		System.out.println("String before Inserting : "+sb1);
	    sb1.insert(10 , "Learning center ");
		sb1.insert(39, ",Trichy.");
		System.out.println("String after Inserting : "+sb1);


	}
}
