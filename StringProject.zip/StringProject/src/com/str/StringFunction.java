//Program for user name and password validation
package com.str;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class UserValidation
{
	private String uname;
	private String upass;
	public void inputData() throws IOException
	{
		InputStreamReader is=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(is);     //readLine()-->String ,read()-->ASCII value
		System.out.println("Enter name");
		uname=br.readLine();
		System.out.println("Enter the password");
		upass=br.readLine();
	}
	public void userValidate()
	{
		if(uname.equals("Admin") && (upass.equals("admin123")))
		{
			System.out.println("Username and password are equal");
		}
		else
		{
			System.out.println("Invalid user");
		}
	}
	public void userValidate1()
	{
		if(uname.equalsIgnoreCase("admin")  && (upass.equalsIgnoreCase("admin123")))
		{
			
		}
		
	}
	
}

public class StringFunction {

	public static void main(String[] args) throws IOException {
		UserValidation uob=new UserValidation();
		uob.inputData();
		uob.userValidate();
	
	}

}
