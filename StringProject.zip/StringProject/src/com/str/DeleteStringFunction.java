package com.str;

public class DeleteStringFunction {
	public static void main(String[] args)
	{
		String str="Edubridges India Learning center";
		StringBuffer sb=new StringBuffer(str);
		System.out.println("String before Deleting : "+sb);
		sb.delete(10, 16);
		sb.deleteCharAt(9);
		System.out.println("String after Deleting :"+sb);
		
	}
	

}
