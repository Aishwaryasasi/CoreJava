package com.str;

import java.util.Scanner;

public class StringReverseOfSubString {

	public static void main(String[] args){
		String st1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the sentence");
		st1=sc.nextLine();
		for(int i=0;i<st1.length();i++)
		{
			char ch=st1.charAt(i);
			if(ch==' ')
			{
				for(int j=st1.length()-1;j>0;j--)
				{
					System.out.print(st1.charAt(j));
				}
			}
			
		}
		sc.close();
		

	}

}
