package com.str;

public class PalindromeString {

	public static void main(String[] args) {
		String s1="madam";
		String rev="";
		for(int i=(s1.length()-1);i>=0;i--)
		{
			rev=rev+s1.charAt(i);
		}
		System.out.println(rev);
		if(s1.equals(rev))
		{
			System.out.println("The string is a palidrome");
		}
		else 
		{
			System.out.println("The string is not a palindrome");
		}

	}

}
