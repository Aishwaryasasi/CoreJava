package com.str;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class Student{
	private int sid;
	private String sname;
	private float sfees;
	
	public void inputStudent() throws IOException {
		BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the student id"); 
		sid=Integer.parseInt(br1.readLine());
		System.out.println("Enter the name");
		sname=br1.readLine();
		System.out.println("Enter the fees");
		sfees=Float.parseFloat(br1.readLine());
		
	}
	public void displayStudent() 
	{
		System.out.println("Student id="+sid);
		System.out.println("Name="+sname);
		System.out.println("Student fees="+sfees);
	}
}


public class BufferedReaderExample {

	public static void main(String[] args) throws IOException {
		Student s1=new Student();
		s1.inputStudent();
		s1.displayStudent();


	}
}


