package com.str;

public class CapacityOfString {

	public static void main(String[] args) {
		String str="Hi! Welcome to IT World";
		StringBuffer sb=new StringBuffer();
		int n=sb.capacity();
		System.out.println("Default capacity = "+n);
		StringBuffer sb1=new StringBuffer(str);
		int n1=sb1.capacity();
		System.out.println("Capacity of the string = "+n1);
	}

}
