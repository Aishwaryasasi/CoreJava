package com.str;

public class Contains {

	public static void main(String[] args) {
		String st="Good Morning";
		System.out.println(st.contains("Good"));//Checks for a word

	}

}
