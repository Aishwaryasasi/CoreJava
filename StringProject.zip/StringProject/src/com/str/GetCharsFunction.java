package com.str;

public class GetCharsFunction {

	public static void main(String[] args) {
		String s1=new String("My Name is Aishwarya");
		char ch[]=new char[10];
		try
		{
			s1.getChars(11, 20, ch, 0);
			System.out.println(ch);
		}
		catch(Exception ex)
		{
			System.out.print(ex);	
			
		}
		
		for(int i=ch.length-2;i>=0;i--)
		{
			System.out.print(ch[i]+"");
		}
		
		
	}
		

}


