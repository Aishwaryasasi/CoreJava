//Program using Append function
package com.str;

public class AppendFunction {

	public static void main(String[] args) {
		String str="Edubridge India";
		StringBuffer sb=new StringBuffer(str);
		System.out.println("String before Appending : "+sb);
		sb.append(" Pvt ltd");
		System.out.println("String after Appending :"+sb);

	}

}
