package com.str;

public class StringExample {

	public static void main(String[] args) {
		String s1="Hello";
		String s2="Hello";
		if(s1==s2)
		{
			System.out.println("S1 and S2 are equal");
		}
		else
		{
			System.out.println("s1 and s2 are not equal");
		}
		String s3=new String("Hi");
		String s4=new String("Hi");
		if(s3==s4)
		{
			System.out.println("S3 and S3 are equal");
		}
		else
		{
			System.out.println("s3 and s4 are not Equal");
		}

	}

}
