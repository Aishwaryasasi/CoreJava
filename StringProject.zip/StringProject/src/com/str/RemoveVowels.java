//Program to remove vowels from the given string
package com.str;

import java.util.Scanner;
class Vowels
{
	private String st1;
	private String st2="";
	
	void input()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the sentence");
		st1=sc.nextLine();
		sc.close();
	}
	void AfterVowels()
	{
		for(int i=0;i<st1.length();i++)
		{
			char ch=st1.charAt(i);
			if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' ||ch=='A' || ch=='E' || ch=='I' || ch=='O' || ch=='U')
			{
				continue;
			}
			else
			{
				st2=st2+st1.charAt(i);
			}
			
		}
		System.out.println("String after removing a vowel : "+st2);
	}
	void revereString()
	{
		String st3="";
		for(int j=st2.length()-1;j>=0;j--)
		{ 
			st3=st3+st2.charAt(j);               //s.o.p(st2.charAt(j);
		}
		System.out.println("String after reversing : "+st3);
		
	}
}
public class RemoveVowels {

	public static void main(String[] args) {
		Vowels vob=new Vowels();
		vob.input();
		vob.AfterVowels();
		vob.revereString();
		}
}
